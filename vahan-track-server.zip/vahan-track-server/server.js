require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const XLSX = require('xlsx');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET is not set. Set it in your .env file (see .env.example).');
  process.exit(1);
}

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---------- Security middleware ----------
app.use(helmet({
  contentSecurityPolicy: false // relaxed for the simple bundled frontend; tighten if you split frontend/backend
}));
app.use(cors()); // allow all origins by default — restrict via CORS_ORIGIN env var if hosting frontend separately
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, 'public')));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many login attempts. Try again in a few minutes.' }
});

const genId = (prefix) => prefix + '_' + crypto.randomBytes(8).toString('hex');

// ---------- Auth helpers ----------
function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Login required' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired, please log in again' });
  }
}
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

// ---------- Multer (uploads) ----------
const photoUpload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, genId('photo') + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!/^image\/(jpeg|png|webp)$/.test(file.mimetype)) return cb(new Error('Only JPG/PNG/WEBP images allowed'));
    cb(null, true);
  }
});
const excelUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /\.(xlsx|xls|csv)$/i.test(file.originalname);
    if (!ok) return cb(new Error('Only .xlsx, .xls or .csv files allowed'));
    cb(null, true);
  }
});

// ============ AUTH ============
app.post('/api/auth/login', loginLimiter, (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  const staff = db.prepare('SELECT * FROM staff WHERE username = ?').get(String(username).toLowerCase());
  if (!staff || !bcrypt.compareSync(password, staff.password_hash)) {
    return res.status(401).json({ error: 'Username or password is incorrect' });
  }
  const token = jwt.sign({ id: staff.id, name: staff.name, role: staff.role, username: staff.username }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token, user: { id: staff.id, name: staff.name, role: staff.role, username: staff.username } });
});

app.get('/api/me', authenticate, (req, res) => res.json({ user: req.user }));

// ============ DASHBOARD ============
app.get('/api/stats', authenticate, (req, res) => {
  const totalCustomers = db.prepare('SELECT COUNT(*) c FROM customers').get().c;
  const totalDue = db.prepare('SELECT COALESCE(SUM(total_due),0) s FROM customers').get().s;
  const overdue = db.prepare(`SELECT COUNT(*) c FROM customers WHERE total_due > 0 AND next_due_date IS NOT NULL AND next_due_date != '' AND date(next_due_date) < date('now')`).get().c;
  res.json({ totalCustomers, totalDue, overdue });
});

app.get('/api/activity/recent', authenticate, (req, res) => {
  const rows = db.prepare(`
    SELECT i.*, c.name as customer_name FROM interactions i
    JOIN customers c ON c.id = i.customer_id
    ORDER BY i.date DESC LIMIT 8
  `).all();
  res.json(rows);
});

// ============ CUSTOMERS ============
app.get('/api/customers', authenticate, (req, res) => {
  const q = (req.query.q || '').trim();
  let rows;
  if (q) {
    const like = `%${q}%`;
    rows = db.prepare('SELECT * FROM customers WHERE name LIKE ? OR bike_model LIKE ? OR phone LIKE ? ORDER BY name').all(like, like, like);
  } else {
    rows = db.prepare('SELECT * FROM customers ORDER BY name').all();
  }
  res.json(rows);
});

app.get('/api/customers/:id', authenticate, (req, res) => {
  const row = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Customer not found' });
  res.json(row);
});

app.post('/api/customers', authenticate, (req, res) => {
  const b = req.body || {};
  if (!b.name || !String(b.name).trim()) return res.status(400).json({ error: 'Customer name is required' });
  const id = genId('cust');
  db.prepare(`INSERT INTO customers (id,name,bike_model,phone,address,loan_amount,total_paid,total_due,emi_amount,next_due_date)
              VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(id, String(b.name).trim(), b.bikeModel || '', b.phone || '', b.address || '',
         Number(b.loanAmount) || 0, Number(b.totalPaid) || 0, Number(b.totalDue) || 0,
         Number(b.emiAmount) || 0, b.nextDueDate || '');
  res.status(201).json(db.prepare('SELECT * FROM customers WHERE id = ?').get(id));
});

app.put('/api/customers/:id', authenticate, (req, res) => {
  const existing = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Customer not found' });
  const b = req.body || {};
  db.prepare(`UPDATE customers SET name=?, bike_model=?, phone=?, address=?, loan_amount=?, total_paid=?, total_due=?, emi_amount=?, next_due_date=?, updated_at=datetime('now') WHERE id=?`)
    .run(
      b.name ?? existing.name, b.bikeModel ?? existing.bike_model, b.phone ?? existing.phone,
      b.address ?? existing.address, b.loanAmount ?? existing.loan_amount, b.totalPaid ?? existing.total_paid,
      b.totalDue ?? existing.total_due, b.emiAmount ?? existing.emi_amount, b.nextDueDate ?? existing.next_due_date,
      req.params.id
    );
  res.json(db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id));
});

app.delete('/api/customers/:id', authenticate, adminOnly, (req, res) => {
  db.prepare('DELETE FROM customers WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---- Bulk import from Excel/CSV ----
// Expected column headers (case-insensitive, flexible): Name, Bike Model, Phone, Address,
// Loan Amount, Total Paid, Total Due, EMI Amount, Next Due Date (YYYY-MM-DD)
app.post('/api/customers/import', authenticate, excelUpload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  let rows;
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
  } catch (e) {
    return res.status(400).json({ error: 'Could not read file. Make sure it is a valid Excel/CSV file.' });
  }

  const norm = (obj, keys) => {
    for (const k of Object.keys(obj)) {
      const kk = k.trim().toLowerCase();
      for (const target of keys) if (kk === target) return obj[k];
    }
    return '';
  };
  const toDateStr = (v) => {
    if (!v) return '';
    if (v instanceof Date) return v.toISOString().slice(0, 10);
    const s = String(v).trim();
    const d = new Date(s);
    return isNaN(d) ? '' : d.toISOString().slice(0, 10);
  };

  const insert = db.prepare(`INSERT INTO customers (id,name,bike_model,phone,address,loan_amount,total_paid,total_due,emi_amount,next_due_date)
                              VALUES (?,?,?,?,?,?,?,?,?,?)`);
  let added = 0, skipped = 0;
  const tx = db.transaction((list) => {
    for (const r of list) {
      const name = String(norm(r, ['name', 'customer name', 'bike owner name'])).trim();
      if (!name) { skipped++; continue; }
      insert.run(
        genId('cust'), name,
        String(norm(r, ['bike model', 'bikemodel', 'vehicle model', 'model'])).trim(),
        String(norm(r, ['phone', 'phone number', 'mobile'])).trim(),
        String(norm(r, ['address'])).trim(),
        Number(norm(r, ['loan amount', 'loanamount'])) || 0,
        Number(norm(r, ['total paid', 'paid', 'totalpaid'])) || 0,
        Number(norm(r, ['total due', 'due', 'totaldue', 'baaki'])) || 0,
        Number(norm(r, ['emi amount', 'emi', 'emiamount'])) || 0,
        toDateStr(norm(r, ['next due date', 'due date', 'nextduedate']))
      );
      added++;
    }
  });
  tx(rows);
  res.json({ added, skipped, total: rows.length });
});

// ============ INTERACTIONS (calls / visits) ============
app.get('/api/customers/:id/interactions', authenticate, (req, res) => {
  const rows = db.prepare('SELECT * FROM interactions WHERE customer_id = ? ORDER BY date DESC').all(req.params.id);
  res.json(rows);
});

app.post('/api/customers/:id/interactions', authenticate, photoUpload.single('photo'), (req, res) => {
  const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(req.params.id);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });
  const { type, notes, location } = req.body;
  if (!['call', 'visit'].includes(type)) return res.status(400).json({ error: 'Type must be call or visit' });
  const id = genId('act');
  const photoPath = req.file ? `/uploads/${req.file.filename}` : null;
  db.prepare(`INSERT INTO interactions (id,customer_id,type,staff_id,staff_name,date,notes,location,photo_path)
              VALUES (?,?,?,?,?,datetime('now'),?,?,?)`)
    .run(id, req.params.id, type, req.user.id, req.user.name, notes || '', location || '', photoPath);
  res.status(201).json(db.prepare('SELECT * FROM interactions WHERE id = ?').get(id));
});

// ============ STAFF (admin only) ============
app.get('/api/staff', authenticate, adminOnly, (req, res) => {
  res.json(db.prepare('SELECT id,name,username,role,created_at FROM staff ORDER BY role DESC, name').all());
});

app.post('/api/staff', authenticate, adminOnly, (req, res) => {
  const { name, username, password } = req.body || {};
  if (!name || !username || !password) return res.status(400).json({ error: 'Name, username and password required' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  const exists = db.prepare('SELECT 1 FROM staff WHERE username = ?').get(String(username).toLowerCase());
  if (exists) return res.status(409).json({ error: 'Username already taken' });
  const id = genId('stf');
  const hash = bcrypt.hashSync(password, 10);
  db.prepare('INSERT INTO staff (id,name,username,password_hash,role) VALUES (?,?,?,?,?)')
    .run(id, name.trim(), String(username).trim().toLowerCase(), hash, 'staff');
  res.status(201).json({ id, name, username, role: 'staff' });
});

app.patch('/api/staff/:id/password', authenticate, (req, res) => {
  if (req.user.role !== 'admin' && req.user.id !== req.params.id) {
    return res.status(403).json({ error: 'Not allowed' });
  }
  const { password } = req.body || {};
  if (!password || password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  db.prepare('UPDATE staff SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(password, 10), req.params.id);
  res.json({ ok: true });
});

app.delete('/api/staff/:id', authenticate, adminOnly, (req, res) => {
  const target = db.prepare('SELECT role FROM staff WHERE id = ?').get(req.params.id);
  if (target && target.role === 'admin') return res.status(400).json({ error: 'Cannot remove an admin account' });
  db.prepare('DELETE FROM staff WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Fallback to frontend ----------
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

app.listen(PORT, () => console.log(`Vahan Track server running on port ${PORT}`));
