const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.sqlite');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS staff (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'staff',
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  bike_model TEXT,
  phone TEXT,
  address TEXT,
  loan_amount REAL DEFAULT 0,
  total_paid REAL DEFAULT 0,
  total_due REAL DEFAULT 0,
  emi_amount REAL DEFAULT 0,
  next_due_date TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS interactions (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK(type IN ('call','visit')),
  staff_id TEXT,
  staff_name TEXT,
  date TEXT NOT NULL,
  notes TEXT,
  location TEXT,
  photo_path TEXT
);

CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_interactions_customer ON interactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_interactions_date ON interactions(date);
`);

// Seed a default admin account only if no staff exists yet
const staffCount = db.prepare('SELECT COUNT(*) AS c FROM staff').get().c;
if (staffCount === 0) {
  const id = 'stf_' + crypto.randomBytes(6).toString('hex');
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO staff (id, name, username, password_hash, role) VALUES (?,?,?,?,?)')
    .run(id, 'Admin', 'admin', hash, 'admin');
  console.log('----------------------------------------------------');
  console.log('Seeded default admin login: admin / admin123');
  console.log('IMPORTANT: log in and change this password immediately.');
  console.log('----------------------------------------------------');
}

module.exports = db;
